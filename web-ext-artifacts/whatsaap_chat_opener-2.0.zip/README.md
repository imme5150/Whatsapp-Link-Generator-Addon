# Whatsapp link generator for Browsers

With this add-on you don't need to save a number to send a message using WhatsApp Web.

This Add-on generates an whatsapp api link to send messages to a given brazilian number.

It only support numbers with International Dialling Codes +55 of Brazil.

![Whatsapp Link Generator](./images/addon.png)