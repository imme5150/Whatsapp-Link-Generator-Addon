# Whatsapp link generator for Browsers

With this add-on you don't need to create a contact to send a message using WhatsApp Web.

This Add-on lets you set your country code in the preferences and then select a phone number, right click on it and select "Open as WhatsApp web chat" and it will open a new tab with a chat to that phone number if it is a valid WhatsApp number.

Feel free to add a translation in the `/_locales` directory or open up an issue or start a discussion.
